var TweetStore = {

	tweetUrl : "https://twitter.com/jensuki/status/530638667178852352",

	tweetId : "530638667178852352",

	accountVerifyCredentials : {
		"id" : 54256387,
		"id_str" : "54256387",
		"name" : "Ryan Choi",
		"screen_name" : "rchoi",
		"location" : "",
		"profile_location" : null,
		"description" : "Developer Advocate @twitter. @salesforce, @zuora, @ycombinator & @thestyleup. @MITSloan @UCBerkeley.",
		"url" : "http:\/\/t.co\/CHeu1Fok2J",
		"entities" : {
			"url" : {
				"urls" : [ {
					"url" : "http:\/\/t.co\/CHeu1Fok2J",
					"expanded_url" : "http:\/\/www.linkedin.com\/in\/ryankicks",
					"display_url" : "linkedin.com\/in\/ryankicks",
					"indices" : [ 0, 22 ]
				} ]
			},
			"description" : {
				"urls" : []
			}
		},
		"protected" : false,
		"followers_count" : 1900,
		"friends_count" : 951,
		"listed_count" : 40,
		"created_at" : "Mon Jul 06 16:38:08 +0000 2009",
		"favourites_count" : 2654,
		"utc_offset" : -28800,
		"time_zone" : "Pacific Time (US & Canada)",
		"geo_enabled" : true,
		"verified" : false,
		"statuses_count" : 1627,
		"lang" : "en",
		"status" : {
			"created_at" : "Sun Nov 16 22:20:29 +0000 2014",
			"id" : 534108772500008960,
			"id_str" : "534108772500008960",
			"text" : "@jackie_bona http:\/\/t.co\/UrEFwxLWOb",
			"source" : "\u003ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003eTwitter for iPhone\u003c\/a\u003e",
			"truncated" : false,
			"in_reply_to_status_id" : 534107738570510336,
			"in_reply_to_status_id_str" : "534107738570510336",
			"in_reply_to_user_id" : 985935006,
			"in_reply_to_user_id_str" : "985935006",
			"in_reply_to_screen_name" : "jackie_bona",
			"geo" : null,
			"coordinates" : null,
			"place" : null,
			"contributors" : null,
			"retweet_count" : 0,
			"favorite_count" : 0,
			"entities" : {
				"hashtags" : [],
				"symbols" : [],
				"user_mentions" : [ {
					"screen_name" : "jackie_bona",
					"name" : "Jackie Bona",
					"id" : 985935006,
					"id_str" : "985935006",
					"indices" : [ 0, 12 ]
				} ],
				"urls" : [],
				"media" : [ {
					"id" : 534108765386440704,
					"id_str" : "534108765386440704",
					"indices" : [ 13, 35 ],
					"media_url" : "http:\/\/pbs.twimg.com\/media\/B2mJF6BIAAAvr1p.jpg",
					"media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2mJF6BIAAAvr1p.jpg",
					"url" : "http:\/\/t.co\/UrEFwxLWOb",
					"display_url" : "pic.twitter.com\/UrEFwxLWOb",
					"expanded_url" : "http:\/\/twitter.com\/rchoi\/status\/534108772500008960\/photo\/1",
					"type" : "photo",
					"sizes" : {
						"thumb" : {
							"w" : 150,
							"h" : 150,
							"resize" : "crop"
						},
						"small" : {
							"w" : 340,
							"h" : 191,
							"resize" : "fit"
						},
						"medium" : {
							"w" : 600,
							"h" : 337,
							"resize" : "fit"
						},
						"large" : {
							"w" : 1024,
							"h" : 576,
							"resize" : "fit"
						}
					}
				} ]
			},
			"favorited" : false,
			"retweeted" : false,
			"possibly_sensitive" : false,
			"lang" : "und"
		},
		"contributors_enabled" : false,
		"is_translator" : false,
		"is_translation_enabled" : false,
		"profile_background_color" : "000000",
		"profile_background_image_url" : "http:\/\/abs.twimg.com\/images\/themes\/theme1\/bg.png",
		"profile_background_image_url_https" : "https:\/\/abs.twimg.com\/images\/themes\/theme1\/bg.png",
		"profile_background_tile" : false,
		"profile_image_url" : "http:\/\/pbs.twimg.com\/profile_images\/478056696216948738\/XL-CdzIl_normal.jpeg",
		"profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478056696216948738\/XL-CdzIl_normal.jpeg",
		"profile_banner_url" : "https:\/\/pbs.twimg.com\/profile_banners\/54256387\/1380176177",
		"profile_link_color" : "3B94D9",
		"profile_sidebar_border_color" : "000000",
		"profile_sidebar_fill_color" : "000000",
		"profile_text_color" : "000000",
		"profile_use_background_image" : false,
		"default_profile" : false,
		"default_profile_image" : false,
		"following" : false,
		"follow_request_sent" : false,
		"notifications" : false
	},

	statusesOembed : {
		"html" : "<blockquote>something</blockquote>",
		"url" : "https://twitter.com/jensuki/status/530638667178852352"
	},

}
